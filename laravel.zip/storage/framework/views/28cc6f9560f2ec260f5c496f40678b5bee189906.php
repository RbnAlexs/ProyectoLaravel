<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <ul class="breadcrumb">
            <li><a href="#">Políticas y Procedimientos</a>
            </li>
            <li>Nuestras Políticas/Código de Ética</li>
        </ul>

    </div>

    <section class="section1">
        <div class="text-center">
            <div class="col-lg-12 col-md-12 col-sm-12">
                    <h5 style="color: #92928F">Política de Autos Utilitarios <a href="<?php echo e(asset('archivos/empresa/POLITICA DE AUTOS UTILITARIOS.pdf')); ?>" download>Descargar</a>.</h5>
                    <h5 style="color: #92928F">Política de Código de Conducta Ética <a href="<?php echo e(asset('archivos/empresa/PoliticadeCodigodeConductaEtica.pdf')); ?>" download>Descargar</a>.</h5>
                    <!-- <embed src="<?php echo e(asset('archivos/empresa/PoliticadeCodigodeConductaEtica.pdf')); ?>" width="800px" height="800px" /> -->
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="clearfix">&nbsp;</div>
                </p>
            </div>
        </div><!-- end message -->
    </section><!-- end section2 -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>