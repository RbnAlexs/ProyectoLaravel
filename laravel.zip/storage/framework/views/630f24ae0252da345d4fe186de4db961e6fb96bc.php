<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="col-md-12">

            <ul class="breadcrumb">
                <li><a href="#">Administración</a>
                </li>
                <li>Roles</li>
            </ul>

        </div>
        <div class="col-md-3">
            <div class="panel panel-default sidebar-menu">

                <div class="panel-heading">
                    <h3 class="panel-title">Menu Administración</h3>
                </div>

                <div class="panel-body">
                    <ul class="nav nav-pills nav-stacked">
                        <li>
                            <a href="<?php echo e(url('/admin/usuarios')); ?>">Usuarios</a>
                        </li>
                        <li class="active">
                            <a href="<?php echo e(url('/admin/roles')); ?>">Roles</a>
                        </li>
                        <!--<li>
                            <a href="<?php echo e(url('/admin/recibos')); ?>">Recibos</a>
                        </li>-->
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-9" data-animate="fadeInDown">
            <div class="box" id="contact">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-<?php echo e(Session::get('message')[0]); ?> alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('message')[1]); ?>

                    </div>
                <?php endif; ?>
                <h1>Administración de Roles</h1>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th class="text-center">Nombre</th>
                        <th class="text-center">Fecha Registro</th>
                        <th class="text-center">Fecha Actualización</th>
                        <th class="text-center">Estatus</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php foreach($roles as $rol): ?>
                        <tr>
                            <td class="table-text text-center"><?php echo e($rol->name); ?></td>
                            <td class="table-text text-center"><?php echo e($rol->created_at); ?></td>
                            <td class="table-text text-center"><?php echo e($rol->updated_at); ?></td>
                            <?php if($rol->estatus == 1): ?>
                                <td class="table-text text-center">
                                    <span class="text-success">Activo</span>
                                </td>
                            <?php else: ?>
                                <td class="table-text text-center">
                                    <span class="text-danger">Inactivo</span>
                                </td>
                            <?php endif; ?>
                            <td class="table-text text-center">
                                <a class="glyphicon glyphicon-pencil" href="<?php echo e(url('/admin/roles/'.$rol->id.'/edit')); ?>" aria-hidden="true">Editar</a>
                                <a class="glyphicon glyphicon-remove" href="<?php echo e(url('/admin/roles/logicaldelete/'.$rol->id)); ?>" aria-hidden="true">Eliminar</a>
                            </td>
                        </tr>

                    <?php endforeach; ?>
                    </tbody>
                </table>
                <nav>
                    <ul class="pagination">
                        <?php if($roles->previousPageUrl()): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($roles->previousPageUrl()); ?>" aria-label="Previous">
                                    <span aria-hidden="true">«</span>
                                    <span class="sr-only">Previous</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php for($i = 1; $i <= $roles->lastPage(); $i++): ?>
                            <?php if($roles->currentPage() == $i ): ?>
                                <li class="page-item active">
                                    <a class="page-link" href="#"><?php echo e($roles->currentPage()); ?>

                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($roles->url($i)); ?>">
                                        <?php echo e($i); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php if($roles->nextPageUrl()): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($roles->nextPageUrl()); ?>" aria-label="Next">
                                    <span aria-hidden="true">»</span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <hr>
                <div class="text-center">
                    <p><a class="btn btn-block btn-success" href="<?php echo e(url('/admin/roles/create')); ?>">Agregar Nuevo Rol</a></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>