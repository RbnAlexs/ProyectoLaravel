# Español

Traducción de archivos de idioma de Laravel en Español.

Contribuir: https://github.com/Laraveles/lang-spanish
