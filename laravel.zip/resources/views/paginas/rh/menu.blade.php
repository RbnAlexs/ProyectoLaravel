@extends('paginas.rh.index')
@section('contentindex')
        <div class="col-md-9" data-animate="fadeInDown">
            <div class="box" id="contact">
                <h1>Recursos Humanos</h1>
                <p>En esta sección podras consultar tus recibos de nómina asi como consultar y solicitar vacaciones</p>
            </div>
        </div>
@endsection